
const express = require("express");
const app = express();
const http = require("http").createServer(app);
const io = require("socket.io")(http);
const path = require("path");

const PORT = process.env.PORT || 3000;

app.use(express.static(path.join(__dirname, "public")));

let players = [];
let cards = [];
let turn = 0;

const generateCards = () => {
  const icons = [
    "🐶", "🐱", "🐭", "🐹", "🦊", "🐻", "🐼", "🐸"
  ];
  const pairIcons = [...icons, ...icons];
  for (let i = pairIcons.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [pairIcons[i], pairIcons[j]] = [pairIcons[j], pairIcons[i]];
  }
  return pairIcons.map((icon, index) => ({
    id: index,
    icon,
    matched: false,
  }));
};

io.on("connection", (socket) => {
  console.log("A user connected:", socket.id);

  if (players.length < 2) {
    players.push({ id: socket.id, name: `Player ${players.length + 1}` });
    socket.emit("playerInfo", { id: socket.id, name: players[players.length - 1].name });
  }

  if (players.length === 2 && cards.length === 0) {
    cards = generateCards();
    io.emit("startGame", { cards, players });
  }

  socket.on("flipCard", ({ id, index }) => {
    socket.broadcast.emit("opponentFlip", { index });
  });

  socket.on("matchResult", ({ matched, firstIndex, secondIndex }) => {
    io.emit("updateCards", { matched, firstIndex, secondIndex });
  });

  socket.on("switchTurn", () => {
    turn = (turn + 1) % 2;
    io.emit("changeTurn", turn);
  });

  socket.on("disconnect", () => {
    console.log("A user disconnected:", socket.id);
    players = players.filter(player => player.id !== socket.id);
    cards = [];
    io.emit("playerLeft");
  });
});

http.listen(PORT, () => {
  console.log("Server is running on port", PORT);
});
