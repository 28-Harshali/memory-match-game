
const socket = io();
let playerId = "";
let playerName = "";
let cards = [];
let flipped = [];
let lockBoard = true;
let currentTurn = 0;

const board = document.getElementById("game-board");
const notification = document.getElementById("notification");
const themeBtn = document.getElementById("toggle-theme");
let darkTheme = true;

themeBtn.addEventListener("click", () => {
  document.body.classList.toggle("dark");
});

socket.on("playerInfo", (data) => {
  playerId = data.id;
  playerName = data.name;
});

socket.on("startGame", (data) => {
  cards = data.cards;
  board.innerHTML = "";
  cards.forEach((card, index) => {
    const div = document.createElement("div");
    div.classList.add("card");
    div.dataset.index = index;
    board.appendChild(div);
  });
  lockBoard = false;
  updateNotification();
});

board.addEventListener("click", (e) => {
  const target = e.target;
  if (!target.classList.contains("card") || lockBoard) return;

  const index = parseInt(target.dataset.index);
  if (flipped.includes(index) || cards[index].matched) return;

  flipCard(target, index);
  socket.emit("flipCard", { id: playerId, index });

  flipped.push(index);

  if (flipped.length === 2) {
    lockBoard = true;
    const [first, second] = flipped;
    const isMatch = cards[first].icon === cards[second].icon;
    setTimeout(() => {
      if (isMatch) {
        cards[first].matched = true;
        cards[second].matched = true;
        document.querySelector(`[data-index='${first}']`).classList.add("matched");
        document.querySelector(`[data-index='${second}']`).classList.add("matched");
      } else {
        unflipCard(first);
        unflipCard(second);
      }
      socket.emit("matchResult", { matched: isMatch, firstIndex: first, secondIndex: second });
      socket.emit("switchTurn");
      flipped = [];
    }, 1000);
  }
});

socket.on("opponentFlip", ({ index }) => {
  const div = document.querySelector(`[data-index='${index}']`);
  if (div && !cards[index].matched) {
    flipCard(div, index);
  }
});

socket.on("updateCards", ({ matched, firstIndex, secondIndex }) => {
  if (matched) {
    document.querySelector(`[data-index='${firstIndex}']`).classList.add("matched");
    document.querySelector(`[data-index='${secondIndex}']`).classList.add("matched");
    cards[firstIndex].matched = true;
    cards[secondIndex].matched = true;
  } else {
    setTimeout(() => {
      unflipCard(firstIndex);
      unflipCard(secondIndex);
    }, 500);
  }
});

socket.on("changeTurn", (turn) => {
  currentTurn = turn;
  lockBoard = (players[currentTurn].id !== playerId);
  updateNotification();
});

socket.on("playerLeft", () => {
  notification.innerText = "Opponent left. Waiting for player...";
  lockBoard = true;
});

function flipCard(div, index) {
  div.classList.add("flipped");
  div.innerText = cards[index].icon;
}

function unflipCard(index) {
  const div = document.querySelector(`[data-index='${index}']`);
  div.classList.remove("flipped");
  div.innerText = "";
}

function updateNotification() {
  notification.innerText = currentTurn === 0 ? "Player 1's turn" : "Player 2's turn";
}
